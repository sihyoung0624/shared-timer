# 모두의 타이머 MCP

[모두의 타이머](https://shared-timer-d07t.onrender.com)를 **Claude가 직접 만들고 제어**할 수 있게 해주는 MCP 서버입니다.

Claude에게 이렇게 말하면 됩니다:
- "발표용 5분 타이머 만들어줘" → 뷰어 링크가 생김
- "타이머 시작해줘" / "1분 더 추가해줘" / "화면에 '곧 시작합니다' 띄워줘"

---

## 무엇을 할 수 있나 (도구 12개)

| 도구 | 설명 |
|---|---|
| `create_timer` | 새 타이머 생성 (뷰어·컨트롤러 링크 발급) |
| `get_timer_state` | 남은 시간·상태 읽기 (토큰 불필요) |
| `start_timer` / `pause_timer` / `reset_timer` | 시작 / 일시정지 / 리셋 |
| `adjust_timer` | 남은 시간 ± 초 단위 조절 |
| `show_message` / `clear_message` | 화면에 문구 표시 / 지우기 |
| `schedule_start` / `cancel_scheduled_start` | 지정 시각 자동 시작 예약 / 취소 |
| `schedule_add` / `schedule_remove` | 일정(어젠다) 추가 / 제거 |

---

## 동작 원리 (한눈에)

- **타이머 생성**은 HTTP(`POST /create`)로 합니다.
- **타이머 제어**(시작·정지·리셋 등)는 실시간 소켓(socket.io)으로 합니다.

즉, 이미 있는 "모두의 타이머" 서버에 붙어서 명령을 전달하는 **얇은 번역기**입니다. 별도 서버 배포가 필요 없고, 각자 자기 PC에서 실행합니다.

---

## 설치

```bash
# 파이썬 3.10 이상 필요
pip install -r requirements.txt
```

## Claude Desktop 에 연결하기

`claude_desktop_config.json` 파일의 `mcpServers` 안에 아래를 추가하세요.
(`/절대경로/` 부분은 이 파일이 있는 실제 경로로 바꾸세요.)

```json
{
  "mcpServers": {
    "moduui-timer": {
      "command": "python",
      "args": ["/절대경로/timer_mcp.py"],
      "env": { "TIMER_BASE_URL": "https://shared-timer-d07t.onrender.com" }
    }
  }
}
```

설정 후 Claude Desktop 을 다시 시작하고 이렇게 말해보세요:
> "발표용 3분 타이머 만들어줘"

---

## ⚠️ 알아두어야 할 점

- **token 은 '제어 비밀번호'입니다.** 타이머를 만들면 `room_id` 와 `token` 이 나오는데, 이 둘을 아는 사람은 그 타이머를 조종할 수 있습니다. **남에게는 뷰어 링크(`viewer_url`)만** 주고, 컨트롤러 링크(토큰 포함)는 본인만 가지세요.
- **이 MCP 는 기본적으로 위 render 서버에 붙습니다.** 자기만의 서버를 따로 운영한다면 `TIMER_BASE_URL` 환경변수를 그 주소로 바꾸면 됩니다.
- **미확정 항목 1개**: `schedule_add` 의 시간(`at`) 형식은 아직 확정하지 못했습니다. 사용 시 값 형식이 맞는지 확인이 필요합니다.

---

## 라이선스

MIT License — 자유롭게 쓰고 고치고 공유할 수 있습니다. (`LICENSE` 파일 참고)
